#!/bin/sh
echo $0
java -Xdock:icon=AlgoBuildSplash.png -jar AlgoBuild085.jar
